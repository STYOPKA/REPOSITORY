﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace WindowsFormsApplication5
{
    public partial class Form6 : Form
    {
        private readonly string TemplateFileName = @"C:\Users\pc\Desktop\коллектив\zadanie_l2_09.02.03\Ресурсы\Шаблон договора.docx";
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var wordApp = new Word.Application();
            wordApp.Visible = false;
            var WordDocument = wordApp.Documents.Open(TemplateFileName);
        }
    }
}
