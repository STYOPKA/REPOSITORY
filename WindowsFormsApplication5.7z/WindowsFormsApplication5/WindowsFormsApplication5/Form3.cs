﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.Text += trackBar1.Value;
            //textBox1.Text = "";
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox2.Text += trackBar2.Value;
            Double S, SP, SG, month;
            Double sn = Convert.ToDouble(textBox1.Text);
            Double sr = Convert.ToDouble(textBox2.Text);

            SP = sn / 100 * 8;
            SG = sn + SP;
            month = SG / 12;
            S = sn + month * sr;
            string f = Convert.ToString(S);
            linkLabel1.Text = f;
            //textBox2.Text = "";
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox3.Text += trackBar3.Value;
            Double S, S2, SP, SP2, SG, SG2, month, month2;
            Double sn = Convert.ToDouble(textBox1.Text);
            Double sr = Convert.ToDouble(textBox2.Text);
            Double se = Convert.ToDouble(textBox3.Text);

            sn = sn + se;

            SP = sn / 100 * 5;
            SP2 = sn / 100 * 6;
            SG = sn + SP;
            SG2 = sn + SP2;
            month = SG / 12;
            month2 = SG2 / 12;
            S = sn + month * sr;
            S2 = sn + month2 * sr;
            string f = Convert.ToString(S);
            string f2 = Convert.ToString(S2);
            linkLabel2.Text = f;
            linkLabel3.Text = f2;
            //textBox3.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 f4 = new WindowsFormsApplication5.Form4();
            f4.Show();
            f4.label8.Text = linkLabel1.Text;
            f4.label9.Text = linkLabel2.Text;
            f4.label10.Text = linkLabel3.Text;
            float sum = Convert.ToInt32(textBox1.Text);
            float srokvk = Convert.ToInt32(textBox2.Text);
            float monrefill = Convert.ToInt32(textBox3.Text);
            float prsum1 = (sum / 100 * 8) / 12 * srokvk;
            float prsum2 = ((sum + monrefill) / 100 * 5) / 12 * srokvk;
            float prsum3 = ((sum + monrefill) / 100 * 6) / 12 * srokvk;
            float yearsum1 = sum + prsum1;
            float yearsum2 = sum + prsum2;
            float yearsum3 = sum + prsum3;
            f4.label11.Text = yearsum1.ToString();
            f4.label12.Text = yearsum2.ToString();
            f4.label13.Text = yearsum3.ToString();
            Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

