﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication5
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string user_Login = textBox1.Text.Trim();
            string user_Password = textBox2.Text.Trim();

            SqlConnection ERDConnectionString = new SqlConnection(@"Data Source=DESKTOP-LD7VU3B;Initial Catalog=collective.isip182;Integrated Security=True");
            string query = "SELECT * FROM User1 WHERE Login = '" + textBox1.Text + "' and Password = '" + textBox2.Text + "'";
            ERDConnectionString.Open();
            SqlCommand cmd = new SqlCommand(query, ERDConnectionString);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                }
                reader.Close();
                ERDConnectionString.Close();
                {
                    Form6 f6 = new Form6();
                    f6.Show();
                    
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
       
        
    }
    }

        
